<?php phpinfo();
